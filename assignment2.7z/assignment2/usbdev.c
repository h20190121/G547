#include<linux/kernel.h>
#include<linux/module.h>
#include<linux/usb.h>
#include<linux/slab.h>

#define CARD_READER_VID  0x14cd
#define CARD_READER_PID  0x125d

#define SAMSUNG_MEDIA_VID  0x04e8
#define SAMSUNG_MEDIA_PID  0x6860

#define SANDISK_MEDIA_VID  0x0781
#define SANDISK_MEDIA_PID  0x5597   //My Pendrive

#define BULK_EP_IN    0x81
#define BULK_EP_OUT   0x02

#define RETRY_MAX                     5
#define REQUEST_SENSE_LENGTH          0x12
#define INQUIRY_LENGTH                0x24
#define READ_CAPACITY_LENGTH          0x08

#define be_to_int32(buf) (((buf)[0]<<24)|((buf)[1]<<16)|((buf)[2]<<8)|(buf)[3])

struct command_block_wrapper {
	uint8_t dCBWSignature[4];
	uint32_t dCBWTag;
	uint32_t dCBWDataTransferLength;
	uint8_t bmCBWFlags;
	uint8_t bCBWLUN;
	uint8_t bCBWCBLength;
	uint8_t CBWCB[16];
};

// Section 5.2: Command Status Wrapper (CSW)
struct command_status_wrapper {
	uint8_t dCSWSignature[4];
	uint32_t dCSWTag;
	uint32_t dCSWDataResidue;
	uint8_t bCSWStatus;
};

static uint8_t cdb_length[256] = {
//	 0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F
	06,06,06,06,06,06,06,06,06,06,06,06,06,06,06,06,  //  0
	06,06,06,06,06,06,06,06,06,06,06,06,06,06,06,06,  //  1
	10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,  //  2
	10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,  //  3
	10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,  //  4
	10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,  //  5
	00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,  //  6
	00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,  //  7
	16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,  //  8
	16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,  //  9
	12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,  //  A
	12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,  //  B
	00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,  //  C
	00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,  //  D
	00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,  //  E
	00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,  //  F
};


struct usbdev_private
{
	struct usb_device *udev;
	unsigned char class;
	unsigned char subclass;
	unsigned char protocol;
	unsigned char ep_in;
	unsigned char ep_out;
};

struct usbdev_private *p_usbdev_info;

static void usbdev_disconnect(struct usb_interface *interface)
{
	printk(KERN_INFO "USBDEV Device Removed\n");
	return;
}

static struct usb_device_id usbdev_table [] = {
	{USB_DEVICE(CARD_READER_VID, CARD_READER_PID)},
	{USB_DEVICE(SAMSUNG_MEDIA_VID, SAMSUNG_MEDIA_PID)},
	{USB_DEVICE(SANDISK_MEDIA_VID, SANDISK_MEDIA_PID)},//My Device
	{} /*terminating entry*/	
};


static int cbw_bulk_message(struct usb_device *udev, uint8_t *cdb)
{
	//uint8_t lun;
	uint32_t max_lba, block_size;
	int device_size;
	int temp;
	int temp1;
	int retval, ret;
    int read_cnt;
	char vid[9] , pid[9] , rev[5] ;
    uint8_t cdb_len;
	int i,  size;
	static uint32_t tag = 1;
	uint8_t *buffer = (uint8_t *)kmalloc(64*sizeof(uint8_t), GFP_KERNEL); 
	struct command_block_wrapper *cbw;
    cbw = (struct command_block_wrapper *)kmalloc(sizeof(struct command_block_wrapper), GFP_KERNEL);
	
	for(i=0; i<64; i++)
	{
		*(buffer+i) = 0;
	}
	
	printk(KERN_INFO "Reading capacity:\n");
	cdb_len = cdb_length[cdb[0]];
	printk(KERN_INFO "cdb_len = %d\n", cdb_len);
    	memset(cbw, 0, sizeof(struct command_block_wrapper));
	cbw->dCBWSignature[0] = 'U';
	cbw->dCBWSignature[1] = 'S';
	cbw->dCBWSignature[2] = 'B';
	cbw->dCBWSignature[3] = 'C';
	cbw->dCBWTag = tag++;
	cbw->dCBWDataTransferLength = READ_CAPACITY_LENGTH;
	cbw->bmCBWFlags = 0x80;
	cbw->bCBWLUN = 0;
	// Subclass is 1 or 6 => cdb_len
	cbw->bCBWCBLength = cdb_len;
	
	memcpy(cbw->CBWCB, cdb, cdb_len);
	
	i = 0;
	do {
	retval = usb_bulk_msg(udev, usb_sndbulkpipe(udev, BULK_EP_OUT), (void *)cbw, 31, &read_cnt, 1000);
    if (retval)
    {
        printk(KERN_ERR "Bulk message sent %d\n", retval);
        
    }
	printk(KERN_INFO "read count = %d\n", read_cnt);
	i++;
	} while ((retval < 0) && (i<RETRY_MAX));


	ret = usb_bulk_msg(udev, usb_rcvbulkpipe(udev, 0x81), (void *)buffer, READ_CAPACITY_LENGTH , &size, 1000);
    if (ret)
    {
        printk(KERN_ERR "Bulk message returned %d\n", ret);
		ret = usb_clear_halt(udev, usb_rcvbulkpipe(udev, BULK_EP_IN));
        
    }
	if (ret)
    {
        printk(KERN_ERR "clear halt %d\n", ret);
		
    }
	
	printk(KERN_INFO "received %d bytes\n", size);
	


	
	max_lba = be_to_int32(&buffer[0]);
	block_size = be_to_int32(&buffer[4]);
	temp=1024*1024;
	temp1=((max_lba+1)/(temp)*(block_size));
	device_size=temp1/1024;
	//device_size = ((double)(max_lba+1))*block_size/(1024*1024*1024);
	printk(KERN_INFO " Max LBA: %d, Block Size: %d\n", max_lba, block_size);
	
	printk(KERN_INFO "Maximum Capacity is: %dGB\n",device_size);
	return 0;
	
}

static int usbdev_probe(struct usb_interface *interface, const struct usb_device_id *id)
{
	unsigned char epAddr, epAttr;
	int i;
	uint8_t cdb[16];
	int ret;
	

	struct usb_device *udev = interface_to_usbdev(interface); //container_of macro can be used
	struct usb_endpoint_descriptor *ep_desc; 
	
	
	
	if(id->idProduct == CARD_READER_PID)
	{
		printk(KERN_INFO "Camera Plugged in\n");
	}
	else if(id->idProduct == SAMSUNG_MEDIA_PID)
	{
		printk(KERN_INFO "Samsung Media Plugged in\n");
	}
	else if(id->idProduct == SANDISK_MEDIA_PID)
	{
		printk(KERN_INFO "Known USB detected:Sandisk Media Plugged in\n");
	}

	
	printk(KERN_INFO "No. of Altsettings = %d\n",interface->num_altsetting);

	printk(KERN_INFO "No. of Endpoints = %d\n", interface->cur_altsetting->desc.bNumEndpoints);

	for(i=0;i<interface->cur_altsetting->desc.bNumEndpoints;i++)
	{
		ep_desc = &interface->cur_altsetting->endpoint[i].desc;
		epAddr = ep_desc->bEndpointAddress;
		epAttr = ep_desc->bmAttributes;
	
		if((epAttr & USB_ENDPOINT_XFERTYPE_MASK)==USB_ENDPOINT_XFER_BULK)
		{
			if(epAddr & 0x80)
				printk(KERN_INFO "EP %d is Bulk IN addr  %d\n", i, epAddr);
			else
				printk(KERN_INFO "EP %d is Bulk OUT addr %d\n", i, epAddr);
	
		}

	}
    
	
	memset(cdb, 0, sizeof(cdb));
	
	
	ret = cbw_bulk_message(udev, cdb);
    if(ret != 0)
	{
		printk(KERN_INFO "cbw unsuccesfull\n");
	}
	
	printk(KERN_INFO "Pendrive (VID,PID) : (%04X,%04X) inserted\n",id->idVendor,id->idProduct);
	printk(KERN_INFO "USB DEVICE CLASS : %x", interface->cur_altsetting->desc.bInterfaceClass);
	printk(KERN_INFO "USB DEVICE SUB CLASS : %x", interface->cur_altsetting->desc.bInterfaceSubClass);
	printk(KERN_INFO "USB DEVICE Protocol : %x", interface->cur_altsetting->desc.bInterfaceProtocol);

return 0;
}



/*Operations structure*/
static struct usb_driver usbdev_driver = {
	name: "sandisk_dev",  //name of the device
	probe: usbdev_probe, // Whenever Device is plugged in
	disconnect: usbdev_disconnect, // When we remove a device
	id_table: usbdev_table, //  List of devices served by this driver
};


static int __init device_init(void)
{	printk(KERN_INFO "UAS READ Capacity Driver Inserted");
	usb_register(&usbdev_driver);
	return 0;
}

static void __exit device_exit(void)
{
	usb_deregister(&usbdev_driver);
	printk(KERN_NOTICE "Leaving Kernel\n");
	//return 0;
}

module_init(device_init);
module_exit(device_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("NILANKAN BISWAS h20190121@pilani.bits-pilani.ac.in");
MODULE_DESCRIPTION("Pen Driver");



